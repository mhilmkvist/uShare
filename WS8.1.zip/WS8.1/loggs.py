# -*- coding: utf-8 -*-
from bottle import route, template, request, response
import os
import uuid, OpenSSL
import time
import hashlib # for password encription with md5

from text_p import *

""" Sign up, log in and log out """

@route('/sign up')
def sign_up():
    """
    Shows a form which allows the user to input its personal data in order to create an account.
    This form is sent via POST to /create account.
    """
    return template("sign_up", not_comp="", email='')


@route('/create account', method="POST")
def update_accounts():
    """
    Receives surname, name, email and password from a form, and adds them
    in a text file
    """

    m = hashlib.md5() # encript (cryptographic hash function)
    # one way function easy --> hard <--

    sname = request.forms.sname
    name = request.forms.name
    email = request.forms.email
    password = request.forms.password
    password2 = request.forms.password2
    m.update(request.forms.password)
    pass_enc = m.hexdigest()

    not_comp = f_validation(sname, name, email, password, password2)

    if (len(not_comp)):
        # change design
        return  template("sign_up", not_comp=not_comp, email='')

    else:
        new_a = sname + ' ' + name + ' ' + email + ' ' + pass_enc + ' ' + '0' + ' ' + '\n'

        mode = 'a' # add to the text not rewrite
        path = os.path.abspath('date/accounts.txt')
        path = path.replace("\\", "/")
        fob = open(path, mode)
        fob.write(new_a)
        fob.close()
        text_af = "Det skapades ett nytt konto </br>Du får tillgång till ditt konto med din e-post"
        text_af = text_af + email
        return template("account_created", username = text_af, email='')




@route('/login')
def login():
    return template("login.tpl", matching="", email='')


@route('/sign', method="POST")
def sign():
    """
    Receives surname, name, email and password from a form, and adds them
    in a text file
    """
    email = request.forms.email
    m = hashlib.md5() # encript (cryptographic hash function)
    m.update(request.forms.password)
    pass_enc = m.hexdigest()

    mode = 'r+' # Opens a file for both reading and writing.
    #The file pointer placed at the beginning of the file.
    path = os.path.abspath('date/accounts.txt')
    path = path.replace("\\", "/")
    searchfile = open(path, mode)

    g_p = "" # the password in the database
    email_f = False # email in database

    list_f = searchfile.readlines()
    searchfile.seek(0)

    i = -1
    for line in searchfile:
        i=i+1
        if email in line:
            li = line.split()
            g_p = li[3] # password
            email_f = True
            if g_p == pass_enc:
                li[4] = "1\n"
                line_c = ' '.join(li)
                list_f[i] = line_c
                searchfile.seek(0)
                searchfile.writelines(list_f)
                searchfile.close()

                # start session
                sid = uuid.UUID(bytes = OpenSSL.rand.bytes(16))
                # the cookie persists when the browser is closed
                response.set_cookie("account", sid, secret='some-secret-key', expires=(int(time.time()) + 3600))

                write_s(email, sid)
                link = "<a href='/conversations'>Diskussioner</a>"
                return template("template", base="</br><p align='center'>Sign in</p>" + link, email = email)
            else:
                searchfile.close()
                return template("login.tpl", matching="</br><p align='center'>Felaktig lösenord.</p>", email='')
    if not(email_f):
        searchfile.close()
        return template("login.tpl", matching="</br><p align='center'>Ange ett annat e-post.</p>", email = '')




@route('/logout')
def logout():
    """ Delete the sid from the session db and the cookie """

    sid = request.get_cookie("account", secret='some-secret-key')
    delete_session(str(sid))
    response.delete_cookie("account") # deletes the cookie


    return "Utloggad"













