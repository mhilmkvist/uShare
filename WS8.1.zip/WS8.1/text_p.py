# -*- coding: utf-8 -*-
import os
import re # for regular expressions

""" Functions for processing the text from the files, the text from the forms and the text from the cookies """



def pass_validation(password):
    """ Password strength validation """
    """ The password has to contain at least 8 characters {8, } """
    """ The password must contain at least une digit, one special character, one lowercase and one uppercase"""

    if re.match(r'^(?=.*?\d)(?=.*?[A-Z])(?=.*?[a-z])(?=.*?\W)[A-Za-z\d\W]{8,}$', password):
        return True
    else:
        return False


def email_validation(email):
    """ Email validation """
    """ The email has to contain at least one [at] symbol subsequently followed by a dot """

    if re.match(r'[^@]+@[^@]+\.[^@]+', email):
        return True
    else:
        return False


def email_exist(email):
    """ Checks whether the email exists in the accounts db """

    mode = 'r'
    path = os.path.abspath('date/accounts.txt')
    path = path.replace("\\", "/")
    fob = open(path, mode)
    all_text = fob.read()
    fob.close()
    if email in all_text:
        return True
    else:
        return False

def f_validation(sname, name, email, password, password2):
    """ Form validation """
    """ The form has to be completed, the email valid and the password strong """

    not_comp = ''
    if len(sname) == 0:
        not_comp = not_comp + 'Glömt efternamn<br/>'
    if len(name) == 0:
        not_comp = not_comp + 'Glömt förnamn</br>'
    if len(email) == 0:
        not_comp = not_comp + 'Glömt mail</br>'
    if len(password) == 0:
        not_comp = not_comp + 'Glömt lösenord</br>'
    if len(password2) == 0:
        not_comp = not_comp + 'Glömt lösenord. Ange ditt lösenord</br>'

    if password != password2:
        not_comp = not_comp + 'Lösenord matchar inte</br>'

    p_v = pass_validation(password)
    if not(p_v):
        not_comp = not_comp + 'Ange ett annat lösenord. Lösenordet är inte tillräckligt stark.</br>'

    e_v = email_validation(email)
    if not(e_v):
        not_comp = not_comp + 'Ogiltig e-post</br>'

    exists = email_exist(email)
    if exists:
        not_comp = not_comp + 'E-post finns redan</br>'


    return not_comp




def write_s(email, sid):
    """ Adds the email and the session id the the session db """

    mode = 'a' # Open for writing.  The file is created if it does not exist.
    #The stream is positioned at the end of the file.


    path = os.path.abspath('date/sessions.txt')
    path = path.replace("\\", "/")
    fob = open(path, mode)
    fob.write(email + " " + str(sid) + '\n')

    fob.close()


def get_email(sid):
    """ Using the session id stored in the cookie the function retrieves the user email """

    mode = 'r+' # Opens a file for both reading and writing.
    #The file pointer placed at the beginning of the file.
    path = os.path.abspath('date/sessions.txt')
    path = path.replace("\\", "/")
    searchfile = open(path, mode)

    in_list = False
    searchfile.seek(0)
    for line in searchfile:
        if sid in line:
            in_list = True
            li = line.split()
            searchfile.close()
            return li[0]
    if not(in_list):
        searchfile.close()
        return False



def delete_session(sid):
    """ When a user loggs out its session is deleted form the session db """

    updated=''
    mode = 'r+'
    path = os.path.abspath('date/sessions.txt')
    path = path.replace("\\", "/")
    searchfile = open(path, mode)

    for line in searchfile:
        if not(sid in line):
            updated = updated + line

    searchfile.close()
    searchfile = open(path, 'w')
    searchfile.writelines(updated)
    searchfile.close()

